#!/bin/bash
#
# OpenVPN Gateway Builder

#    OpenVPN Gateway Builder is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.

#    OpenVPN Gateway Builder is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with OpenVPN Gateway Builder; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#
# Copyright (C) 2005-2007 Schlomo Schapiro
#
# Author: Schlomo Schapiro <ogb@schlomo.schapiro.or> [GSS]
#
VERSION="1.7"

CHANGES='
2005-05-25	GSS	Initial Version
2005-05-26	GSS	Fix kernel modules, add openvpn autostart
2005-05-27	GSS	Split into modular packages
2005-05-29	GSS	Fix all bugs from the split into modular packages
2005-06-16	GSS	Adapt to run off Debian (file locations, ...)
2005-07-05	GSS	Add some better logging support, logging stderr to a logfile
2005-07-18	GSS	Made OGB work on SuSE9.3 (SharedObjectFiles problem)
2005-07-19	GSS	Fixed SNMP Package, problem with usr/lib directories in package skeletons and usr/lib -> /lib symlink in ogb skeleton
2005-07-28	GSS	Add GPL license, copyright, docs
2005-10-23	GSS	Create ISO dir if needed, initialize progress bar properly
2005-11-04	GSS	Include /etc/localtime for correct timezone setting, include vmware package
2007-06-18	GSS	Added syslinux support, network startup modularized, early syslog start. Renamed MEDIAFS to Boot Media
2007-06-20	GSS	Packages can also define modules
2007-08-07	GSS	Added crond package
2007-08-08	GSS	Optimized boot order (start syslog, ppp before netsetup.sh) ...
2007-08-16	GSS	Include skeleton dir from gateway config, remove -v and -d
2007-09-07	GSS	Support having customer packages (custom-*) that are not part of the OGB distribution
2007-09-18	GSS	serial-console package, minor fixes, add serial support to boot loader
2007-10-22	GSS	added templates/ feature to merge gateway templates
'

# Versioning
RELEASE="$(echo "$CHANGES" | tail -n 2 | cut -c 1-10)"
PRODUCT="OpenVPN Gateway Builder"

# Defaults:
BASEDIR="/opt/ogb"
ISODIR="$BASEDIR/ISO"
GATEWAYS="$BASEDIR/gateways"
VERBOSE=""
DEBUG=""
BUILD=""
OUTPUT=""
DEFAULT_PACKAGES=( openvpn )
KERNEL_CMDLINE=""
KERNEL_VERSION="$(uname -r)"

BUILDNR="$(cd "$BASEDIR" ; FILES=( $(find packages skeleton -type f -and -not -name \*~) ogb.sh lib/functions.sh lib/isolinux.bin) ; ( echo ${FILES[@]} ; cat ${FILES[@]} ) | md5sum | cut -d " " -f 1)"

USAGE="$( basename "$0") [Options] <config> [packages ...]"'
'"$PRODUCT Version $VERSION / $RELEASE"'
'"Build $BUILDNR"'
Copyright (C) 2005-2007 Schlomo Schapiro
'"$PRODUCT"' comes with ABSOLUTELY NO WARRANTY; for details 
see the GNU General Public License at http://www.gnu.org/licenses/gpl.html
Available Options:
-V			version information
-t			Trace OGB scripts
-r a.b.c-xx-yy		kernel version to use (current: '"$KERNEL_VERSION"')
-i			create OGB ISO image in default path ('"$ISODIR"')
-I /some/path/here	create OGB ISO image in in specified path

Available Packages:
'"$(cd "$BASEDIR"/packages/ ; for k in * ; do
	printf "%20s   %s\n" "$k" "$(test -r $k/description && head -n 1 $k/description)"
done)
Default Packages: ${DEFAULT_PACKAGES[@]}

Available Templates:
$(cd "$BASEDIR"/templates/ ; for k in * ; do
	printf "%20s   %s\n" "$k" "$(test -r $k/description && head -n 1 $k/description)"
done)"


ETC_APPEND_FILES=(
syslog-ng.conf
hosts
)

ETC_COPY=(
HOSTNAME
resolv.conf
modules
network.sh
iptables.conf
)

PROGS=(
bash
grep
cat
tr
awk
ip
iptables
ebtables
arptables
iptables-restore
syslog-ng
klogd
echo
cp
date
false
wc
cut
rm
test
init
ethtool
expand
sed
mount
umount
insmod
modprobe
brctl
tunctl
vconfig
hostname
uname
sleep
logger
lsmod
ps
ping
ps
netstat
free
seq
mv
basename
dirname
mkdir
uniq
rev
tac
tee
sort
)

LIBS=( "$(ls /lib/libnss_dns* /lib/libnss_files*)" )

. "$BASEDIR/lib/functions.sh"
test $# -eq 0 -o "${*//*--help*/--help}" == "--help" && Usage

# Parse options
while getopts "VhvdtiI:r:" Option
do
	case $Option in
	h ) Usage ;;
	V ) Print "$PRODUCT Version $VERSION / $RELEASE\nBuild: $BUILDNR\nLast changes:$(echo "$CHANGES" | tail -n 10)" ; exit 0 ;;
	v ) VERBOSE=1 ;;
	d ) DEBUG=1 ; VERBOSE=1 ;;
	t ) set -x ;;
	I ) ISODIR="$OPTARG" ; OUTPUT=ISO ;;
	i ) OUTPUT=ISO ;;
	r ) KERNEL_VERSION="$OPTARG" ;;
	* ) Error "Unknown Option $Option specified." ;;
	esac
done
shift $(($OPTIND - 1))
# Move argument pointer to next.

GW="$1" ; shift
test "$GW" || Error "You must specify a Gateway configuration !"

# set the logfile for error logs
LOGFILE="$BASEDIR/log/ogb-$GW.log"
test -r "$LOGFILE" && mv "$LOGFILE" "$LOGFILE".old # keep old log file

GWCONF="$GATEWAYS/$GW"
test -d "$GWCONF" || Error "$GW is not a valid Gateway configuration (look in $GATEWAYS) !"

# set template (use array to truncate all space)
TEMPLATE=
if test -s "$GWCONF/TEMPLATE" ; then
       	TEMPLATE=( $(cat "$GWCONF/TEMPLATE") )
	# merge template
	test -d "$BASEDIR/templates/$TEMPLATE" || Error "Template '$TEMPLATE' not found !"
	Log "Merging template '$TEMPLATE'"
	ProgressStart "Merging template '$TEMPLATE'"
	cp -va "$BASEDIR/templates/$TEMPLATE/gateway/." "$GWCONF/" 2>>"$LOGFILE"  1>&8
	ProgressStopIfError $? "Could not merge template '$TEMPLATE'"
	# Read local gateway configuration and replace vars 
	test -s $GWCONF/TEMPLATE_CONFIG.sh
	ProgressStopIfError $? "$GWCONF/TEMPLATE_CONFIG.sh is missing !"
	. $GWCONF/TEMPLATE_CONFIG.sh
	# do all the patching in the gateway config
	pushd $GWCONF >/dev/null
	for key in ${!TEMPLATE_*} ; do
		key=${key#TEMPLATE_} # cut off the leading TEMPLATE_ from the variable name
		Log "Patching $key in selected configuration files"
		export TEMPLATE_$key
		# patch all files (except keys and TEMPLATE_*) in the gateway config
		perl -i -p -e 's/'$key'/$ENV{"TEMPLATE_'$key'"}/g' $( find . -type f ! -name TEMPLATE\* ! -name \*~ ! -name \*.p12 ! -name \*key* ! -name \*pem )
		ProgressStep
	done
	popd >/dev/null
	ProgressStop
fi


v=""
verbose=""
# Prepare stuff
if test "$VERBOSE" ; then
	v="-v"
	verbose="--verbose"
fi

VERSION_INFO="
$PRODUCT Version $VERSION / $RELEASE
Build: $BUILDNR
Copyright (C) 2005-2007 Schlomo Schapiro
$PRODUCT comes with ABSOLUTELY NO WARRANTY; for details
see the GNU General Public License at http://www.gnu.org/licenses/gpl.html
Configuration '$GW' $(test "$TEMPLATE" && echo "Template '$TEMPLATE'")
"

Print "$VERSION_INFO"

shopt -s nullglob

set -- ${DEFAULT_PACKAGES[@]} "$@" $(test -r "$GWCONF/PACKAGES" && cat "$GWCONF/PACKAGES") 

VERSION_ADDONS=""
# Parse packages, include also default packages here
while test $# -gt 0 ; do
	k=$1 ; shift
	echo " ${PACKAGES[@]} " | grep -q " $k " && continue # skip doubles
	if test -d "$BASEDIR/packages/$k" ; then
		PACKAGES=( ${PACKAGES[@]} $k )
		P="$BASEDIR/packages/$k" # package dir
		test -r "$P/PROGS" && PROGS=( ${PROGS[@]} $(cat "$P/PROGS") )
		test -r "$P/LIBS" && LIBS=( ${LIBS[@]} $(cat "$P/LIBS") )
		test -r "$P/ETC_COPY" && ETC_COPY=( ${ETC_COPY[@]} $(cat "$P/ETC_COPY") )
		test -r "$P/ETC_APPEND_FILES" && ETC_APPEND_FILES=( ${ETC_APPEND_FILES[@]} $(cat "$P/ETC_APPEND_FILES") )
	test -r "$P/KERNEL_CMDLINE" && KERNEL_CMDLINE="$KERNEL_CMDLINE $(cat "$P/KERNEL_CMDLINE")"
	test -r "$P/PACKAGES" && set -- "$@" $(cat "$P/PACKAGES") # add required packages
	test -r "$P/VERSION" && VERSION_ADDONS="$VERSION_ADDONS$(cat "$P/VERSION")$LF"
else 
	Error "Unknown package $k" 
fi
done

# append package info to version file
VERSION_INFO="$VERSION_INFO""Packages: ${PACKAGES[@]}$LF$VERSION_ADDONS"

# Start the build process
Log "Starting new build process $VERSION_INFO"

Print "Building with packages: ${PACKAGES[@]}"


##########
# Stage 1: Prepare the build directory with skeleton
BUILD="$BASEDIR/build"

Log "Preparing build directory: $BUILD"
ProgressStart "Preparing build directory"
# clean & copy new skeleton
rm -Rfv "$BUILD" 2>>"$LOGFILE" 1>&8  
ProgressStopIfError $PIPESTATUS "Could not remove build directory: $BUILD"
mkdir -v "$BUILD" 2>>"$LOGFILE" 1>&8
ProgressStopIfError $PIPESTATUS "Could not create build directory: $BUILD"
# copy skeletons by setting up a list of skeleton directories to copy over.
cp -av "$BASEDIR/skeleton/." $(
	for k in ${PACKAGES[@]} ; do
		test -d "$BASEDIR/packages/$k/skeleton" && echo "$BASEDIR/packages/$k/skeleton/." # copy package skeletons
	done
	test "$TEMPLATE" -a -d "$BASEDIR/templates/$TEMPLATE/skeleton" && echo "$BASEDIR/templates/$TEMPLATE/skeleton/." # add skeleton from template
	test -d "$GWCONF/skeleton" && echo "$GWCONF/skeleton/." # add skeleton from gateway config
) "$BUILD/" 2>>"$LOGFILE"  1>&8
ProgressStopIfError $PIPESTATUS "Could not copy to build directory: $BUILD"
ProgressStop


##########
# Stage 2: Copy configurations

# Run prepare for packages
for PACKAGE in ${PACKAGES[@]} ; do
test -r "$BASEDIR/packages/$PACKAGE/prepare.sh" && . "$BASEDIR/packages/$PACKAGE/prepare.sh"
done


Log "Copy configuration files"
ProgressStart "Copy configuration files"

# copy config files
for f in ${ETC_COPY[@]} ; do
test -r "$GWCONF/$f" && {
	cp -a "$GWCONF/$f" "$BUILD/etc/" # copy configs
	ProgressStopIfError $PIPESTATUS "Could not copy configuration file $GWCONF/$f"
}
ProgressStep
done

# append config files
for f in ${ETC_APPEND_FILES[@]} ; do
	test -r "$GWCONF/$f" && {
		cat "$GWCONF/$f" >> "$BUILD/etc/$f" # append configs in /etc
		ProgressStopIfError $PIPESTATUS "Could not append configuration file $GWCONF/$f"
	}
	ProgressStep
done
ProgressStep

# copy timezone file
cat /etc/localtime >"$BUILD/etc/localtime"

# Create /etc/version file
echo "$VERSION_INFO

You can safely turn off this machine at any time

" >>"$BUILD/etc/version"
 
# run configure for packages
# append package modules
for PACKAGE in ${PACKAGES[@]} ; do
	test -r "$BASEDIR/packages/$PACKAGE/configure.sh" && . "$BASEDIR/packages/$PACKAGE/configure.sh"
	test -r "$BASEDIR/packages/$PACKAGE/modules" && cat "$BASEDIR/packages/$PACKAGE/modules" >>"$BUILD/etc/modules"
	ProgressStep
done

# append network setup script to inittab
# we do this here to allow runlevel 1 services (like ppp) to start BEFORE the network setup
echo "net:123:wait:/etc/netsetup.sh" >>"$BUILD/etc/inittab"
ProgressStop

##########
# Stage 3: Copy program files & libraries & needed files
# PROGS is a list of programs. I use type -p to collect the binaries

Log "Copy program files & libraries"
ProgressStart "Copy program files & libraries"
{
# calculate binaries from needed progs
declare -a BINARIES
c=0
for k in "${PROGS[@]}" ; do
	file="$(type -p "$k")"
	if test "$file" ; then
		BINARIES[$c]="$file"
		let c++
		echo "Found $file"
	fi
done
} 1>&8
# copy binaries
BinCopyTo "$BUILD/bin" "${BINARIES[@]}" 2>>"$LOGFILE" 1>&8
ProgressStopIfError $PIPESTATUS "Could not copy binaries"
LIBS=( ${LIBS[@]} $(SharedObjectFiles "${BINARIES[@]}" | sed -e 's#^#/#' 2>>"$LOGFILE") )
LibCopyTo "$BUILD/lib" ${LIBS[@]} 1>&8 2>>"$LOGFILE"
ProgressStopIfError $PIPESTATUS "Could not copy libraries"
ldconfig $v -r "$BUILD" 1>&8 2>>"$LOGFILE"
ProgressStopIfError $PIPESTATUS "Could not configure libraries with ldconfig"
# copy iptables modules, assuming they are in /usr/lib/iptables or in /lib/iptables
mkdir -v "$BUILD/lib/iptables" 1>&8 2>>"$LOGFILE"
LibCopyTo "$BUILD/lib/iptables" /lib/iptables/* /usr/lib/iptables/* 1>&8 2>>"$LOGFILE"
ProgressStopOrError $? "Could not copy iptables plugins"

##########
# Stage 4: Copy modules 
# read list of kernel modules & calculate dependencies
Log "Collecting modules for kernel version $KERNEL_VERSION"
Verbose "Collecting modules for kernel version $KERNEL_VERSION"
ProgressStart "Copy modules"

MODULES=(
$(awk <"$BUILD/etc/modules" '{print $1}')
tun
8021q
af_packet
unix
ebtable_broute 
ebt_vlan 
ebt_arp 
ebt_mark_m 
ebt_log 
ebt_stp 
ebt_arpreply 
ebt_ip 
ebtable_filter 
ebt_limit 
ebtables 
ebt_among 
ebt_dnat 
ebt_pkttype 
ebtable_nat 
ebt_mark 
ebt_snat 
ebt_redirect 
ebt_802_3 
bridge 
arp_tables 
ipchains 
arpt_mangle 
arptable_filter 
nfnetlink
nfnetlink_log
nfnetlink_queue
x_tables
xt_CLASSIFY
xt_CONNMARK
xt_MARK
xt_NFQUEUE
xt_NOTRACK
xt_comment
xt_connbytes
xt_connmark
xt_conntrack
xt_dccp
xt_helper
xt_length
xt_limit
xt_mac
xt_mark
xt_physdev
xt_pkttype
xt_realm
xt_sctp
xt_state
xt_string
xt_tcpmss
xt_tcpudp
arp_tables
arpt_mangle
arptable_filter
ip_conntrack
ip_conntrack_amanda
ip_conntrack_ftp
ip_conntrack_irc
ip_conntrack_netbios_ns
ip_conntrack_netlink
ip_conntrack_pptp
ip_conntrack_proto_sctp
ip_conntrack_tftp
ip_nat
ip_nat_amanda
ip_nat_ftp
ip_nat_irc
ip_nat_pptp
ip_nat_snmp_basic
ip_nat_tftp
ip_queue
ip_tables
ipt_CLUSTERIP
ipt_DSCP
ipt_ECN
ipt_LOG
ipt_MASQUERADE
ipt_NETMAP
ipt_REDIRECT
ipt_REJECT
ipt_SAME
ipt_TCPMSS
ipt_TOS
ipt_TTL
ipt_ULOG
ipt_addrtype
ipt_ah
ipt_dscp
ipt_ecn
ipt_esp
ipt_hashlimit
ipt_iprange
ipt_ipv4options
ipt_multiport
ipt_owner
ipt_policy
ipt_recent
ipt_tos
ipt_ttl
iptable_filter
iptable_mangle
iptable_nat
iptable_raw
)

MODFILES=(
$( ResolveModules "$KERNEL_VERSION" "${MODULES[@]}" 2>>"$LOGFILE" )
)
ProgressStopIfError $? "Could not resolve kernel module dependancies"

# copy modules & depmod
ModulesCopyTo "$BUILD" "${MODFILES[@]}" 1>&8 2>>"$LOGFILE"
ProgressStopIfError $? "Could not copy kernel modules"
depmod -avb "$BUILD" "$KERNEL_VERSION" 1>&8 2>>"$LOGFILE"
ProgressStopOrError $? "Could not configure modules with depmod"

#########
# Stage 5: Make Media filesystem with initrd & kernel
ProgressStart "Create Media filesystem"

MEDIAFS="$BASEDIR/mediafs"

rm -Rfv "$MEDIAFS" 1>&8 2>>"$LOGFILE"
ProgressStopIfError $? "Could not remove Media filesystem directory: $MEDIAFS"
mkdir -v "$MEDIAFS" 1>&8 2>>"$LOGFILE"
ProgressStopIfError $? "Could not create Media filesystem directory: $MEDIAFS"
cd "$BUILD" 
find . ! -name "*~" | tee /dev/fd/8 | cpio -H newc --create --quiet | gzip -9 > "$MEDIAFS/initrd" 2>>"$LOGFILE"
ProgressStopOrError "${PIPESTATUS[2]}" "Could not create initramfs archive"
cd - >/dev/null

# find and copy kernel
# we only tro to find the currently running kernel
# Using another kernel is a TODO for now
KERNEL=""
if test -r "/boot/vmlinuz-$KERNEL_VERSION" ; then
	KERNEL="/boot/vmlinuz-$KERNEL_VERSION"
	Verbose "Using kernel $KERNEL"
elif test "$(type -p get_kernel_version)" ; then
	for k in /boot/* ; do
		if VER=$(get_kernel_version "$k") && test "$VER" == "$KERNEL_VERSION" ; then
			KERNEL="$k"
			Verbose "Found kernel $KERNEL"
			break
		fi
	done
else
	Error "Could not find a matching kernel in /boot !"
fi
cp -a "$KERNEL" "$MEDIAFS/kernel"


# copy ISOLINUX & create isolinux.cfg
cp -a "$BASEDIR/lib/isolinux.bin" "$MEDIAFS/"
# debug run is enabled via runlevel 3, which activates some more stuff
echo "$VERSION_INFO" >"$MEDIAFS/message.txt"
cat >"$MEDIAFS/isolinux.cfg" <<EOF
serial 0 115200 0
display message.txt
prompt 0
timeout 50
totaltimeout 600
label linux
kernel kernel
append initrd=initrd root=/dev/ram vga=normal rw $KERNEL_CMDLINE
EOF
# copy isolinux.cfg to syslinux.cfg for syslinux boot
cp "$MEDIAFS/isolinux.cfg" "$MEDIAFS/syslinux.cfg"
echo "$VERSION_INFO" >"$MEDIAFS/version"
mkdir -p "$MEDIAFS/grub"
cat >"$MEDIAFS/grub/menu.lst" <<EOF
hiddenmenu
timeout 1
root (hd0,0)
title OGB
	cat /boot/version
	kernel /boot/kernel root=/dev/ram vga=normal rw $KERNEL_CMDLINE
	initrd /boot/initrd
EOF
# copy config to MEDIAFS, for reference
tar -C "$GATEWAYS" -c -z -f "$MEDIAFS/$GW.tar.gz" "$GW"

##########
# Stage 6: Create OUTPUT Image
case "$OUTPUT" in
	ISO)
		Log "Starting mkisofs"
		ProgressStart "Making ISO image"
		test -d "$ISODIR" || mkdir -p "$ISODIR" 1>&8 2>>$LOGFILE
		ProgressStopIfError $? "Could not create ISO directory ($ISODIR)"
		mkisofs -o "$ISODIR/$GW.iso" -b isolinux.bin -c boot.cat \
			-no-emul-boot -boot-load-size 4 -boot-info-table \
			-R -J -v "$MEDIAFS" 2>>$LOGFILE 1>&8
		ProgressStopOrError $? "Could not create ISO image"
		Print "The Boot ISO Image can be found in '$ISODIR/$GW.iso'"
	;;
	*)
		Print "The Boot Media files can be found in '$MEDIAFS'"
	;;
esac

Print "$PRODUCT finished for configuration '$GW'"
Log "$PRODUCT finished for configuration '$GW'"
