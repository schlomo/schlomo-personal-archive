echo >>"$BUILD/etc/inittab" "cro:23:respawn:cron -n"
cp -a /lib/security/pam_permit.so $BUILD/lib/security
