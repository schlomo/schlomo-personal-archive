cat <<EOF >>$BUILD/etc/syslog-ng.conf
# log to serial
destination serial { file("/dev/ttyS0"); };
log { source("src"); destination("serial"); };
EOF

sed -i -e 's#cat\(.*/etc/version\)#tee /dev/tty0 <\1#' $BUILD/etc/inittab
