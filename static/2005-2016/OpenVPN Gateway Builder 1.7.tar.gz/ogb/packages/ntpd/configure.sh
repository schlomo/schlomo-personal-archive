cat >>"$BUILD/etc/inittab" <<EOF
ntp:23:respawn:ntpd -g -x -n -p /var/run/ntpd.pid
EOF
