# sync time 
if grep -q ntpd /etc/inittab && test $(grep ^server /etc/ntp.conf | wc -l) -gt 1 ; then
	echo "Setting system time via NTP ..."
	ntpd -q -g # allow for big jumps
	hwclock --systohc --utc
fi


