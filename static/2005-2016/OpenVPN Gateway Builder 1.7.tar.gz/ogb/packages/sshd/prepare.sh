if ! test -f "$GWCONF/ssh_host_dsa_key" ; then
	Print "Generating ssh_host_dsa_key"
	ssh-keygen -t dsa -b 1024 -f "$GWCONF/ssh_host_dsa_key" -N ''
fi
