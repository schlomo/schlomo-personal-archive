echo >>"$BUILD/etc/inittab" "ss:3:respawn:/bin/sshd -D -f /etc/sshd_config"
