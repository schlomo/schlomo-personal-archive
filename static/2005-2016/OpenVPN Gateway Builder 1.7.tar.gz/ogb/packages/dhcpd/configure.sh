cat >>"$BUILD/etc/inittab" <<EOF
dhc:23:respawn:dhcpd -f $(cat $GWCONF/dhcpd.interfaces) >/tmp/dhcpd.log 2>&1
EOF
