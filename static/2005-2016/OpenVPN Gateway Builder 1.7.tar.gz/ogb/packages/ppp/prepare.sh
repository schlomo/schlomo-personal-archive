LIBS=( "${LIBS[@]}" /usr/lib/pppd/*/* )
