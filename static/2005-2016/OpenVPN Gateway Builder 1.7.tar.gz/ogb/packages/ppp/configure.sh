# Build ppp start lines in inittab
echo "$(
cd "$BUILD/etc/ppp/peers"
count=0
for c in * ; do
	# skip *~ files
	if expr match "$c" '.*~' >/dev/null; then 
		continue
	fi
	echo "p$count:123:respawn:bash -c 'sleep 10 ; exec pppd nolog persist call $c'"
	let count++
	ProgressStep
done )" >>"$BUILD/etc/inittab"

