echo "sn:23:respawn:/bin/snmpd -p /var/run/snmpd.pid -Lsd -f -M /etc/mibs -c /etc/snmpd.conf" >>"$BUILD/etc/inittab"
