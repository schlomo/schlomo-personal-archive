cat >>"$BUILD/etc/inittab" <<EOF
sh2:123:respawn:bash --login </dev/tty2 >/dev/tty2 2>&1
sh3:123:respawn:bash --login </dev/tty3 >/dev/tty3 2>&1
EOF

cat >>"$BUILD/etc/netsetup.sh" <<EOF
sleep 2
echo "
! DEBUG MODE, PLEASE DO NOT USE FOR PRODUCTION SYSTEMS !

! SYSLOG-NG IS LOGGING TO /var/log/messages AND NOT ROTATING LOGS !

"
sleep 2
init 3
EOF

# append local logging to syslog-ng
cat >>"$BUILD/etc/syslog-ng.conf" <<EOF
destination messages { file("/var/log/messages"); };
log { source("src"); destination("messages"); };
EOF
