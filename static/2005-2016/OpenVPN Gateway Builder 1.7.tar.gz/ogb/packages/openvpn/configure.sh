# Build OpenVPN start lines in inittab
echo "$(
cd "$BUILD/etc/openvpn" 2>/dev/null || exit 0
count=0
for c in *.conf ; do
	bn=${c%%.conf}
	echo "o$count:23:respawn:openvpn --syslog $bn --writepid /var/run/$bn.pid --config /etc/openvpn/$c --cd /etc/openvpn"
	let count++
	ProgressStep
done )" >>"$BUILD/etc/inittab"


