# Build vmware-guestd start lines in inittab
echo "vmw:23:respawn:/bin/vmware-guestd" >>"$BUILD/etc/inittab"

# append VMware modules. The vmxnet module has to be added by the user becaus it is
# a NIC driver and not a system driver
echo "vmmemctl" >>$BUILD/etc/modules
