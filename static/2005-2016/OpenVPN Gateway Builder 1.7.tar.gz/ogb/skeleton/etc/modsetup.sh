#!/bin/bash

echo -n "Delaying " ; for k in 1 2 3 4 5 ; do echo -n .\ ; sleep 1 ; done ; echo

# load modules
while read module options ; do
	modprobe -v $module $options 2>&1 | logger -t $(basename $0)
done </etc/modules 

# The default firewall is to close everything
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP


