#!/bin/bash

# setup iptables
iptables-restore </etc/iptables.conf

# setup network
. /etc/network.sh

# wait another 2 seconds
sleep 2

# source post-network scripts
for f in /etc/ip-up.d/*.sh ; do
	. "$f"
done

init 2


