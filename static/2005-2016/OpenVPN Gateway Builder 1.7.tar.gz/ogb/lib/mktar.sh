#!/bin/bash
test -e ogb.sh && cd .. || { echo call me from the ogb directory ; exit 5 ; }
eval $(grep ^VERSION= ogb/ogb.sh) # get version from ogb.sh
f=ogb/ogb-$VERSION.tar

N=( $(
	{
		tar -c --exclude 'ogb/templates/*-*' --exclude 'ogb/ogb-*tar*' --exclude '*~' --exclude ogb/build --exclude ogb/ISO --exclude ogb/mediafs --exclude 'ogb/log/*' --exclude '*.swp' --exclude ogb/gateways -v -f "$f" ogb
		tar -r -v -f "$f" --exclude '*~' ogb/gateways/sample*
	} | wc -l )
)
echo "$N files collected"
gzip -9vf "$f"
shopt -s nullglob
custom_packages="$( ls -d1 ogb/packages/custom-* )"
test ${#custom_packages} -gt 6 && cat <<EOF
INFO: Custom packages are NOT part of the OGB distribution:
${custom_packages}
Please make sure to save / backup them yourself !!!
EOF
