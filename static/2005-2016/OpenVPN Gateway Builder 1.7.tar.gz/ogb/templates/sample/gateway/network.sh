# make a bridge br0: eth0,tap0
openvpn --mktun --dev tap0
brctl addbr br0
brctl addif br0 tap0
brctl addif br0 eth0
ip link set eth0 up
ip link set tap0 up

# check what we've done: 
brctl show

# setup br0
ip addr add 192.168.11.99/24 dev br0
ip link set br0 up
ip route add default via 192.168.11.1

# IP routing ?
echo 1 > /proc/sys/net/ipv4/ip_forward

# Dyn IP ?
echo 1 > /proc/sys/net/ipv4/ip_dynaddr

# TCP SYN cookies
echo 1 > /proc/sys/net/ipv4/tcp_syncookies

# Disable ECN
#echo 0 >/proc/sys/net/ipv4/tcp_ecn

# wait for bridge to come up
for k in $(seq 1 15) ; do echo -n . ; sleep 1 ; done ; echo

ping -c 5 -b 192.168.11.16 # NTP
