#
# TEMPLATE VARIABLE Patching
#
# NOTE: The TEMPLATE_ prefix will be REMOVED by ogb prior to patching the files
#	so that you have to specifiy here TEMPLATE_FOO and in the files just FOO !
#


TEMPLATE_MY_DOMAIN='mysample'
TEMPLATE_MY_HOSTNAME=sample
TEMPLATE_MY_DNS=10.12.13.14

