package lib::Config;
use Exporter;
@ISA	= qw(Exporter);
@EXPORT = qw(%NETS @NETS %NAMES %PATTERNS @INFOS %MAPS %PICPATCH %COLORS $debug %COUNTERS 
		@COUNTERS $refreshtime $putipinpix %NUMCOMPS %NUMPIC $lastmodpic $backlog
		$EOL $BLANK $outdir $confdir $conffile $gfxoutdir $numgfxoutdir $remoteport 
		$urlgfx $logdir $logfile $delay
		$graphwidth $graphheight
		&dodebug &readconfig);

$outdir="/usr/local/httpd/labmon/details/";
$confdir="etc/";
$conffile=$confdir . "labmon.conf";
$gfxoutdir=$outdir;
$numgfxoutdir=$outdir;
$remoteport=$numgfxoutdir;
$urlgfx="/labmon/gfx/";
$remoteport="finger(79)";
$backlog="0";
$logdir=$outdir."log/";
$logfile="";
$delay=0;

#@EXPORT_OK = qw(%C &add_log_file);
# %NETS keeps the named list of networks and names to work on
# @NETS keeps the order of the networks list
# %NAMES is a dictionary between short name and display name
# $debug is 1 for debugging output to file
# %PATTERNS is a named list of patterns
# @INFOS is a list of pattern names to use as info to be extracted from the finger response
# $COUNTERS is a list of counters, includes the builtins named busy, free, offline
#		offline means the WS doesn't answer pings, 
#		free means we can't connect to it but it answers pings
#		busy means that we connected and read some data from it.
# 		The counters are initialized with some default patterns
# @COUNTERS keeps the order of the counters listed. First are free,offline,busy
# $refreshtime is the time after which the browser should reload the page, adapts itself automatically
# to the time the script needs the pass all networks
# @MAPS is a hash of IP<->coordinates map to know where to put the markings for busy/free/unknown
# @COLORS is a hash of colors in HTML #RGB format
# @PICPATCH is a hash of picture patches to be done for classes, lists the picture to be taken for each
# class. The pictures should be relative to the conf dir
# $putipinpix tells wether to put the IP number in the network picture
# %NUMCOMPS keeps the real number of computers in a class (if the IP range is larger than the actual amount of
# computers
# %NUMPIC keeps the names of files and networks for that a picture with the numerical result should
# be created
# $lastmodpic if yes, creates a file called lastmod.png with the current time in it at the end of each cycle
# $backlog if yes, create log of status.
# under $logdir create dirs for years/month and files for each day. In each file write one line
# for each network scanned of the format time\tfree\tbusy\toffline\t[customcounter=data\t...].
# The user has to make sure to remove old data
# $delay is the minimum amount of seconds that have to be between two visits to the same net, meaning
# that if labmon passes all nets faster than $delay it will sleep the remaining seconds of $delay to
# ensure that a new run is started every $delay seconds
# $graphwidth,$graphheight are the dimensions of the graphs to create

sub dodebug 
# Deal with debug message @, joining by space
{
	print STDERR "Debug: " . join(" ",@_) . "\n" ;
}



sub readconfig
# Initializes all variables, reads in the config file. It is save to call this from within when
# the config file has changed
{
	%NETS = () ;
	@NETS = () ;
	%NAMES = ( free => "free" , busy => "busy" , offline => "offline") ;
	%PATTERNS = ( free => "FrEe" , busy => "BuSy", offline => "OfFlInE");
	@INFOS = ();
	%MAPS = () ;
	%PICPATCH = () ;
	%COLORS = ( 	free => "00FF00", 
			busy => "FF0000", 
			offline => "000000" , 
			text=> "0000FF", 
			numback=> "000000",
			numfree=> "FFF000",
			numtotal=> "000FFF",
		  );
	$debug = 0 ;
	%COUNTERS = ( free => "0", busy => "0" , offline => "0" );
	@COUNTERS = ( "free" , "offline" , "busy" );
	$refreshtime = 5 ;
	$putipinpix = 0;
	%NUMCOMPS = ();
	%NUMPIC = ();
	$lastmodpic = 0 ;
	$backlog = 0 ;
	$graphwidth = 500 ;
	$graphheight = 200 ;
	open CONF,"<$conffile" || die "Could not open config file $conffile: $@\n";
	my $line=0;
	while (<CONF>)
	{
		chomp;
		$line++;
# If a line starts with a # or contains only whitespace, skip this line
		next if (m/^\s*$/ or m/^\s*#/);
# separate each line into command and parameters, white space allowed. There are no commands without parameters.
# this should also filter out any leading or trailing whitespace
		($command,$parms) = m/^\s*(\w+)\s+(.*\S)\s*$/;
# parse commands
		if ($command eq "debug")
# enable debugging output
		{ 
			$debug = $parms;
			if ($debug)
			{
				&dodebug("Enabled Debugging");
			}
			else
			{
				&dodebug("Disabled Debugging");
			}
		} 
		elsif ($command eq "net")
# Define a new network
# net <name> <address range>
# - name should fit \w+
# - addtess range should be of type a.b.c.d-e (only class C's are supported right now)
		{
			my ($name,$iprange) = $parms =~ m/^(\w+)\s+(\d+\.\d+\.\d+\.\d+-\d+)/;
			die "Invalid net command in $conffile line $line: $parms\n" .
			    "Syntax should be net <name> <a.b.c.d-e>\n" unless ($name and $iprange);
			$NETS{$name}=$iprange;
			push @NETS,$name;
# Add default display name, can be changed by a later name command
			$NAMES{$name}=$name;
			&dodebug("Added net $name = $iprange from $conffile line $line") if ($debug);
		}
		elsif ($command eq "name")
# Define a new display name
# name <name> <Display Name>
# - name should fit \w+
# - Display Name is any text
		{
			my ($name,$display) = $parms =~ m/^(\w+)\s+(\S.*)$/;
			die "Invalid name command in $conffile line $line: $parms\n" .
			    "Syntax should be name <name> <Display Name>" unless ($name and ($display ne ""));
#			$display =~ s/"/\\"/g;
#			print "\$display=\"$display\"\n";
#			eval  "\$display=\"$display\"";
			$NAMES{$name}=$display;
			&dodebug("Added name $name = $display from $conffile line $line") if ($debug);
		}
		elsif ($command eq "numcomps")
# Define a new real amount of computers
# name <name> <Amount of computers>
# - name should fit \w+
# - Amount is a natural number
		{
			my ($name,$number) = $parms =~ m/^(\w+)\s+(\d+).*$/;
			die "Invalid numcomps command in $conffile line $line: $parms\n" .
			    "Syntax should be numcomps <name> <Amount of computers>" unless ($name and ($number ne ""));
			$NUMCOMPS{$name}=$number;
			&dodebug("Added numcomps $name = $number from $conffile line $line") if ($debug);
		}
		elsif ($command eq "numpic")
# Define a new numerical picture for a class
# name <name> <filename>
# - name should fit \w+
# - Filename is the name of the PNG file that will be created in $numgfxoutdir
		{
			my ($name,$file) = $parms =~ m/^(\w+)\s+(\S.*)$/;
			die "Invalid numpic command in $conffile line $line: $parms\n" .
			    "Syntax should be numpic <name> <Filename>" unless ($name and ($file ne ""));
			$NUMPIC{$name}=$file;
			&dodebug("Added numpic $name = $file from $conffile line $line") if ($debug);
		}
		elsif ($command eq "pattern")
# Define a new pattern
# pattern <name> <perl-regex pattern>
# - name should fit \w+
# - pattern should not start with a whitespace
		{
			my ($name,$pattern) = $parms =~ m/^(\w+)\s+(.*)$/;
			die "Invalid pattern command in $conffile line $line: $parms\n" . 
			    "Syntax should be pattern <name> <perl-regex pattern>\n" . 
			    "See the perlre man page for details\n" .
			    "The text to extract has to be enclosed by ()\n" unless ($name and $pattern);
			$PATTERNS{$name}=$pattern;
			$NAMES{$name}=$name;
			&dodebug("Added pattern $name = $pattern from $conffile line $line") if ($debug);
		}
		elsif ($command eq "counter")
# Define a new counter, increases if the pattern is found in the response
# pattern <name>
# - name should fit \w+
		{
			my ($name) = $parms =~ m/^(\w+)$/;
			die "Invalid counter command in $conffile line $line: $parms\n" . 
			    "Syntax should be counter <name>\n" . 
			    "Where name is also the name of a pattern that trigger the counter\n".
			    "The counter counts in how many hosts the pattern matched in the reponse\n" unless ($name);
			$COUNTERS{$name}=0;
			push @COUNTERS,$name;
			$NAMES{$name}=$name;
			&dodebug("Added counter $name from $conffile line $line") if ($debug);
		}
		elsif ($command eq "color")
# Define a color,
# color <name> <HTML-style RGB value>
# - name should fit \w+
# - color is like AABBCC for RGB
		{
			my ($name,$color) = $parms =~ m/^(\w+)\s+(.*)$/;
			die "Invalid color command in $conffile line $line: $parms\n" . 
			    "Syntax should be color <name> <HTML-style RGB value\n" . 
			    "Where name is also the name a color (busy, free, offline are predefined\n".
			    "" unless ($name and $color);
			$COLORS{$name}=$color;
			$NAMES{$name}=$name;
			&dodebug("Added color $name = $color from $conffile line $line") if ($debug);
		}
		elsif ($command eq "map")
# Define a new map that translates between IP and coordinates in a picture. The coordinates are floodfilled
# with a color
# map <name> <filename>
# - name should fit \w+
# - filename is relative to conf-dir
# fileformat:
# 192.168.1.2	20 30
		{
			my ($name,$filename) = $parms =~ m/^(\w+)\s+(.*)$/;
			die "Invalid map command in $conffile line $line: $parms\n" . 
			    "Syntax should be map <name> <filename>\n" . 
			    "Where name is also the name of a net and filename is a map file relative to\n".
			    "the configuration file\n" unless ($name and $filename);
			$MAPS{$name}=$filename;
			&dodebug("Added map $name = $filename from $conffile line $line") if ($debug);
		}
		elsif ($command eq "picpatch")
# Define a new picture to be patched for a network
# picpatch <name> <filename>
# - name should fit \w+
# - filename is relative to conf-dir
		{
			my ($name,$filename) = $parms =~ m/^(\w+)\s+(.*)$/;
			die "Invalid picpatch command in $conffile line $line: $parms\n" . 
			    "Syntax should be map <name> <filename>\n" . 
			    "Where name is also the name of a net and filename is a PNG/JPEG/BMP file relative to\n".
			    "the configuration file\n" unless ($name and $filename);
			$PICPATCH{$name}=$filename;
			&dodebug("Added picpatch $name = $filename from $conffile line $line") if ($debug);
		}
		elsif ($command eq "info")
# Add a new info item to be extraced, named by a pattern
# info <name>
# - name should fit \w+
		{
			my ($name) = $parms =~ m/^(\w+)$/;
			die "Invalid info command in $conffile line $line: $parms\n" .
			    "Syntax should be info <name>\n" .
			    "name is a named pattern\n" unless ($name);
			push @INFOS,$name;
			&dodebug("Added info $name from $conffile line $line") if ($debug);
		}
		elsif ($command eq "option")
# Change an option. Options are all scalar parameters used in the program
# option <name> <Value>
# - name should fit \w+
# - value can be anything
		{
			my ($name,$value) = $parms =~ m/^(\w+)\s+(.*)$/;
			die "Invalid option command in $conffile line $line: $parms\n" .
			    "Syntax should be option <name> <value>\n".
			    "Where name is the name of an option and the value it\'s value\n" unless ($name and $value);
			eval '$' . $name . '=\'' . $value . '\';' ;
			&dodebug("Set option $name = ${$name} from $conffile line $line") if ($debug);
		}
		else
# Warn about unknown things in the config file
		{
			&dodebug("Warning: Unknown command \"$command\" found in $conffile line $line: [$_]") if ($debug);
		}
	}
	close CONF;
	
	
	
} # readconfig


# some really global (= neverchanging) stuff here
# find out some stuff by my own, set some constants
$EOL = "\015\012";
$BLANK = $EOL x 2;

return 1;
