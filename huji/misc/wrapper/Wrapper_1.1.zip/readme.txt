Welcome to wrapper

Installation Instructions:
1) Extract all files into a temporary directory
2) Right-Click wrapper.inf and choose Install
3) Read the wrapper.txt which should open. If it doesn't, read it nevertheless.
4) Copy WrapperConf.exe and wrapper.txt to any directory of your choice and make a shortcut
   to your start menu or desktop
5) run WrapperConf to configure wrapper
6) try out the supplied .wrp files to see how wrapper works.

To use the showproxy.wrp file you have to install an application shortcut to fyi.exe (if you
have it) or change it to use something similar. 
at HUJI you could use:
fyi=\\huji-mars\sys\public\fyi.exe


Have fun,
Schlomo Schapiro
